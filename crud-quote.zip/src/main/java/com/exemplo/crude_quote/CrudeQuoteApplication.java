package com.exemplo.crude_quote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudeQuoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudeQuoteApplication.class, args);
	}

}
